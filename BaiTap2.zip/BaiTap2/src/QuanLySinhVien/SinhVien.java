package QuanLySinhVien;
import java.util.Scanner;

public class SinhVien {
	private int MaSinhVien;
	private String HoTen;
	private  float DiemLT;
	private float DiemTH;
	private float DiemTB;
	
	
	

	public SinhVien(int maSinhVien, String hoTen, float diemLT, float diemTH, float diemTB) {
		
		MaSinhVien = maSinhVien;
		HoTen = hoTen;
		DiemLT = diemLT;
		DiemTH = diemTH;
	
	}
	

	public SinhVien() {
		
		// TODO Auto-generated constructor stub
	}


	public int getMaSinhVien() {
		return MaSinhVien;
	}


	public void setMaSinhVien(int maSinhVien) {
		MaSinhVien = maSinhVien;
	}


	public String getHoTen() {
		return HoTen;
	}


	public void setHoTen(String hoTen) {
		HoTen = hoTen;
	}


	public float getDiemLT() {
		return DiemLT;
	}


	public void setDiemLT(float diemLT) {
		DiemLT = diemLT;
	}


	public float getDiemTH() {
		return DiemTH;
	}


	public void setDiemTH(float diemTH) {
		DiemTH = diemTH;
	}



	@Override
	public String toString() {
		return "SinhVien [MaSinhVien=" + MaSinhVien + ", HoTen=" + HoTen + ", DiemLT=" + DiemLT + ", DiemTH=" + DiemTH
				+ ", DiemTB=" + DiemTB + "]";
	}
	


	public  float getDiemTB(float DiemLT, float DiemTH) {
		
		DiemTB =(DiemLT + DiemTH)/2;
		return  DiemTB;
	}

	public void xuatThongTinSinhVien() {
		
		    System.out.println("Ma Sinh Vien : " + this.getMaSinhVien());
	        System.out.println("Ho Ten: " + this.getHoTen());
	        System.out.println("Diem Ly Thuyet: " + this.getDiemLT());
	        System.out.println("Diem Thuc Hanh: " + this.getDiemTH());
	        System.out.println("Diem Trung Binh: " + this.getDiemTB(this.getDiemLT(), this.getDiemTH()));
		
	}


	public void NhapThongTinSinhVien() {
	    Scanner sc = new Scanner(System.in);
	    
	    while (true) {
	    System.out.print("Ma Sinh Vien: ");
	    int maSinhVien = sc.nextInt();
	    sc.nextLine();
	    
	    if (maSinhVien > 0) {
			setMaSinhVien(maSinhVien);
            break; 
        }
        System.out.println("Ma Sinh Vien khong hop le. Vui long nhap lai.");
    }
	    while (true) {
	    System.out.print("Ho Ten: ");
	    String hoTen = sc.nextLine();
	    
	    if (!hoTen.isEmpty()) {
	    	setHoTen(hoTen);
            break; 
        }
        System.out.println("Ho Ten khong để trống. Vui long nhap lai.");
    }
	    
	    while (true) {
	    System.out.print("Diem Ly Thuyet: ");
	    float diemLT = sc.nextFloat();
	    sc.nextLine();
	    
	    if (diemLT >= 0) {
	    	setDiemLT(diemLT);
            break; 
        }
        System.out.println("Diem ly thuyet khong hop le. Vui long nhap lai.");
    }
	    
	    while (true) {
	    System.out.print("Diem Thuc Hanh: ");
	    float diemTH = sc.nextFloat();
        sc.nextLine();
        
	    if (diemTH >= 0) {
	    	setDiemTH(diemTH);
            break; 
        }
        System.out.println("Diem thuc hanh khong hop le. Vui long nhap lai.");
    }
	    
	    System.out.println("Diem Trung Binh: " + this.getDiemTB(this.getDiemLT(), this.getDiemTH()));
	    
	}



}
