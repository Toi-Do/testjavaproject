package QuanLySinhVien;

public class Main {
	
	public static void main(String[] args) {
		
		
		SinhVien sv1 = new SinhVien(001, "Nguyen Van A", 7, 8, 0);
		sv1.xuatThongTinSinhVien();
		
		System.out.println("**************************");
		
		SinhVien sv2 = new SinhVien(002, "Nguyen Van B", 6, 8, 0);
		sv2.xuatThongTinSinhVien();
		
		System.out.println("**************************");
		
		SinhVien sv3 = new SinhVien();
		sv3.NhapThongTinSinhVien();
		
	}


}
