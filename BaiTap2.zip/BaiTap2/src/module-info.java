/**
 * 
 */
/**
 * @author toido
 *
 */
module BaiTap2 {
}